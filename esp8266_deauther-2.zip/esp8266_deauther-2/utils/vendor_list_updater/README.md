`python3 update_manuf.py -o oui.h -s`  

This Python script updates the manufacturer list oui.h in deauther2.0/esp8266_deauther.  

The -s option is for creating a limited list of the top 1000 vendors. That is enough for most devices and it makes the list fit in 512kb.  